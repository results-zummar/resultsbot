/**
 * Minimal logger. It NEVER receives credentials: callers must not pass the
 * exam number or the secret code. Any 11+ digit run is masked as a safety net.
 */
const maskDigits = (value: string) => value.replace(/\d{11,}/g, "[redacted]");

const format = (level: string, message: string, meta?: Record<string, unknown>) => {
  const safeMeta = meta ? ` ${maskDigits(JSON.stringify(meta))}` : "";
  return `${new Date().toISOString()} [${level}] ${maskDigits(message)}${safeMeta}`;
};

export const logger = {
  info: (message: string, meta?: Record<string, unknown>) =>
    console.log(format("info", message, meta)),
  warn: (message: string, meta?: Record<string, unknown>) =>
    console.warn(format("warn", message, meta)),
  error: (message: string, meta?: Record<string, unknown>) =>
    console.error(format("error", message, meta)),
};

import { NajahError } from "../najah/client.js";
import { logger } from "./logger.js";

/** Error codes that are worth retrying: site down, loading, temporary glitch. */
const RETRYABLE = new Set([
  "SITE_DOWN",
  "CHALLENGE_UNAVAILABLE",
  "PDF_FAILED",
  "NOT_FOUND",
]);

export type RetryOptions = {
  attempts?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
  label?: string;
};

function isRetryable(error: unknown): boolean {
  if (error instanceof NajahError) return RETRYABLE.has(error.code);
  // Network/timeout/unknown failures are transient too.
  return true;
}

/**
 * Keeps trying while the site is loading, erroring or momentarily unavailable.
 * Only a definitive answer (wrong credentials) stops it immediately.
 */
export async function withRetry<T>(fn: () => Promise<T>, options: RetryOptions = {}): Promise<T> {
  const attempts = options.attempts ?? Number(process.env["NAJAH_RETRY_ATTEMPTS"] ?? 6);
  const base = options.baseDelayMs ?? Number(process.env["NAJAH_RETRY_BASE_MS"] ?? 2_000);
  const max = options.maxDelayMs ?? Number(process.env["NAJAH_RETRY_MAX_MS"] ?? 15_000);

  let lastError: unknown;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (!isRetryable(error) || attempt === attempts) break;
      const code = error instanceof NajahError ? error.code : "NETWORK";
      const delay = Math.min(max, base * 2 ** (attempt - 1)) + Math.floor(Math.random() * 500);
      logger.warn("retrying", { label: options.label ?? "call", attempt, code, delay });
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}

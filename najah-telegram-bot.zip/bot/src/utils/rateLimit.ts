const MAX = Number(process.env["RATE_LIMIT_MAX"] ?? 3);
const WINDOW_MS = Number(process.env["RATE_LIMIT_WINDOW_MS"] ?? 3_600_000);

const hits = new Map<number, number[]>();

export function checkRateLimit(userId: number): { allowed: boolean; retryAfterMs: number } {
  const now = Date.now();
  const recent = (hits.get(userId) ?? []).filter((t) => now - t < WINDOW_MS);

  if (recent.length >= MAX) {
    const retryAfterMs = WINDOW_MS - (now - recent[0]!);
    hits.set(userId, recent);
    return { allowed: false, retryAfterMs };
  }

  recent.push(now);
  hits.set(userId, recent);
  return { allowed: true, retryAfterMs: 0 };
}

// Periodic cleanup so the map does not grow forever.
setInterval(() => {
  const now = Date.now();
  for (const [userId, times] of hits) {
    const recent = times.filter((t) => now - t < WINDOW_MS);
    if (recent.length === 0) hits.delete(userId);
    else hits.set(userId, recent);
  }
}, WINDOW_MS).unref?.();

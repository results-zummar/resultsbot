import { Telegraf } from "telegraf";
import { registerHandlers } from "./handlers.js";
import { logger } from "../utils/logger.js";

export function createBot(): Telegraf {
  const token = process.env["TELEGRAM_BOT_TOKEN"];
  if (!token) {
    throw new Error("TELEGRAM_BOT_TOKEN is not set. Copy .env.example to .env and fill it in.");
  }

  const bot = new Telegraf(token, { handlerTimeout: 120_000 });
  registerHandlers(bot);

  bot.catch((error) => {
    logger.error("unhandled bot error", { message: String(error) });
  });

  return bot;
}

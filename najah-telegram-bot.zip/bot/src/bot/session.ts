export type State = "IDLE" | "WAITING_FOR_EXAM_NUMBER" | "WAITING_FOR_SECRET" | "PROCESSING";

export type Session = {
  state: State;
  examNumber?: string;
  /** Held in memory only, for the few seconds between input and lookup. */
  secret?: string;
  updatedAt: number;
};

const sessions = new Map<number, Session>();
const TTL_MS = 5 * 60 * 1000;

export function getSession(userId: number): Session {
  const existing = sessions.get(userId);
  if (existing && Date.now() - existing.updatedAt < TTL_MS) return existing;
  const fresh: Session = { state: "IDLE", updatedAt: Date.now() };
  sessions.set(userId, fresh);
  return fresh;
}

export function setSession(userId: number, patch: Partial<Session>) {
  const session = getSession(userId);
  Object.assign(session, patch, { updatedAt: Date.now() });
  sessions.set(userId, session);
}

/** Wipes the secret (and optionally the whole session) from memory. */
export function clearSecret(userId: number) {
  const session = sessions.get(userId);
  if (session) {
    session.secret = undefined;
    delete session.secret;
  }
}

export function resetSession(userId: number) {
  clearSecret(userId);
  sessions.delete(userId);
}

// Drop stale sessions so no credential can linger in memory.
setInterval(() => {
  const now = Date.now();
  for (const [userId, session] of sessions) {
    if (now - session.updatedAt > TTL_MS) resetSession(userId);
  }
}, 60_000).unref?.();

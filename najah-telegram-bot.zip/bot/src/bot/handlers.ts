import { Markup, type Telegraf } from "telegraf";
import { NajahError } from "../najah/client.js";
import { loginAndFetchResult } from "../najah/login.js";
import { renderResultPdf } from "../najah/pdf.js";
import { hasResult, suggestedFileName } from "../najah/result.js";
import { logger } from "../utils/logger.js";
import { checkRateLimit } from "../utils/rateLimit.js";
import { withRetry } from "../utils/retry.js";
import { clearSecret, getSession, resetSession, setSession } from "./session.js";

const WELCOME = [
  "🎓 أهلاً بك في بوت نتائج نجاح",
  "",
  "اضغط على الزر أدناه لجلب نتيجتك.",
  "",
  "🔒 الخصوصية:",
  "يُستخدم الرقم الامتحاني والرقم السري فقط للاستعلام عن النتيجة، ولا يتم تخزين الرقم السري بعد انتهاء العملية.",
].join("\n");

const HELP = [
  "الأوامر المتاحة:",
  "/start - بدء البوت",
  "/result - جلب النتيجة",
  "/cancel - إلغاء العملية",
  "/help - المساعدة",
].join("\n");

const keyboard = Markup.inlineKeyboard([
  Markup.button.callback("📄 جلب النتيجة", "fetch_result"),
]);

const ERRORS: Record<string, string> = {
  BAD_CREDENTIALS: "❌ البيانات غير صحيحة.\nتأكد من الرقم الامتحاني والرقم السري وحاول مرة أخرى.",
  NOT_FOUND: "🔎 لم يتم العثور على النتيجة.",
  SITE_DOWN: "⚠️ الموقع غير متاح حالياً.\nحاول مرة أخرى بعد قليل.",
  PDF_FAILED: "⚠️ تعذر تحميل ملف النتيجة حالياً.\nحاول مرة أخرى.",
  CHALLENGE_UNAVAILABLE: "⚠️ الموقع غير متاح حالياً.\nحاول مرة أخرى بعد قليل.",
  UNAUTHORIZED_AUTOMATION:
    "🚫 الاستعلام الآلي معطّل.\nصفحة النتائج محمية باختبار تحقق، ويحتاج تشغيل البوت إلى إذن رسمي من الوزارة.",
};

export function registerHandlers(bot: Telegraf) {
  bot.start(async (ctx) => {
    resetSession(ctx.from.id);
    await ctx.reply(WELCOME, keyboard);
  });

  bot.help(async (ctx) => ctx.reply(HELP));

  bot.command("cancel", async (ctx) => {
    resetSession(ctx.from.id);
    await ctx.reply("✅ تم إلغاء العملية.", keyboard);
  });

  bot.command("result", async (ctx) => startFlow(ctx));
  bot.action("fetch_result", async (ctx) => {
    await ctx.answerCbQuery();
    await startFlow(ctx);
  });

  bot.on("text", async (ctx) => {
    const userId = ctx.from.id;
    const session = getSession(userId);
    const value = ctx.message.text.trim();

    if (value.startsWith("/")) return;

    if (session.state === "WAITING_FOR_EXAM_NUMBER") {
      if (!/^\d{15}$/.test(value)) {
        await ctx.reply("❌ الرقم الامتحاني يجب أن يتكون من 15 رقماً. أرسله مرة أخرى:");
        return;
      }
      setSession(userId, { examNumber: value, state: "WAITING_FOR_SECRET" });
      await ctx.reply("🔐 أرسل الرقم السري:");
      return;
    }

    if (session.state === "WAITING_FOR_SECRET") {
      if (!/^\d{14}$/.test(value)) {
        await ctx.reply("❌ الرقم السري يجب أن يتكون من 14 رقماً. أرسله مرة أخرى:");
        return;
      }
      setSession(userId, { secret: value, state: "PROCESSING" });
      await processLookup(ctx, userId);
      return;
    }

    if (session.state === "PROCESSING") {
      await ctx.reply("⏳ جاري البحث عن نتيجتك...");
      return;
    }

    await ctx.reply(WELCOME, keyboard);
  });
}

async function startFlow(ctx: any) {
  const userId = ctx.from.id;
  const { allowed, retryAfterMs } = checkRateLimit(userId);
  if (!allowed) {
    const minutes = Math.ceil(retryAfterMs / 60_000);
    await ctx.reply(`⏱️ لقد أرسلت طلبات كثيرة. حاول مرة أخرى بعد ${minutes} دقيقة.`);
    return;
  }
  resetSession(userId);
  setSession(userId, { state: "WAITING_FOR_EXAM_NUMBER" });
  await ctx.reply("🔢 أرسل الرقم الامتحاني:");
}

async function processLookup(ctx: any, userId: number) {
  const session = getSession(userId);
  const examNumber = session.examNumber!;
  const secret = session.secret!;

  await ctx.reply("⏳ جاري البحث عن نتيجتك...\nقد يستغرق الأمر دقيقة إذا كان الموقع بطيئاً — سأحاول تلقائياً حتى تظهر النتيجة.");

  let pdf: Buffer | null = null;
  try {
    // Keep retrying while the site is loading/erroring; stop only on a
    // definitive answer such as wrong credentials.
    const data = await withRetry(
      async () => {
        const payload = await loginAndFetchResult(examNumber, secret);
        if (!hasResult(payload)) throw new NajahError("NOT_FOUND");
        return payload;
      },
      { label: "lookup" },
    );
    clearSecret(userId);

    pdf = await withRetry(() => renderResultPdf(data), { label: "pdf" });

    await ctx.replyWithDocument(
      { source: pdf, filename: suggestedFileName(examNumber) },
      {
        caption: [
          "🎓 تم العثور على نتيجتك بنجاح.",
          "",
          "📄 ملف النتيجة مرفق.",
          "",
          "بالتوفيق والنجاح ❤️",
        ].join("\n"),
      },
    );
  } catch (error) {
    const code = error instanceof NajahError ? error.code : "SITE_DOWN";
    logger.warn("lookup failed", { code });
    await ctx.reply(ERRORS[code] ?? ERRORS["SITE_DOWN"]!);
  } finally {
    // Wipe every trace of the credentials and the file from memory.
    pdf = null;
    resetSession(userId);
  }
}

import "dotenv/config";
import { createBot } from "./bot/bot.js";
import { closeBrowser } from "./najah/pdf.js";
import { logger } from "./utils/logger.js";

const bot = createBot();

async function shutdown(signal: string) {
  logger.info(`shutting down (${signal})`);
  bot.stop(signal);
  await closeBrowser();
  process.exit(0);
}

process.once("SIGINT", () => void shutdown("SIGINT"));
process.once("SIGTERM", () => void shutdown("SIGTERM"));

bot.telegram.setMyCommands([
  { command: "start", description: "بدء البوت" },
  { command: "result", description: "جلب النتيجة" },
  { command: "cancel", description: "إلغاء العملية" },
  { command: "help", description: "المساعدة" },
]).catch(() => undefined);

logger.info("bot started (long polling)");
void bot.launch();

export const BASE_URL = process.env["NAJAH_BASE_URL"] ?? "https://najah.iq";
export const API_BASE = `${BASE_URL}/api/student`;
export const TIMEOUT_MS = Number(process.env["NAJAH_TIMEOUT_MS"] ?? 30_000);

export class NajahError extends Error {
  constructor(
    public code:
      | "UNAUTHORIZED_AUTOMATION"
      | "SITE_DOWN"
      | "BAD_CREDENTIALS"
      | "NOT_FOUND"
      | "PDF_FAILED"
      | "CHALLENGE_UNAVAILABLE",
    message?: string,
  ) {
    super(message ?? code);
  }
}

/** fetch with a hard timeout; no cookies are stored between calls. */
export async function request(path: string, init: RequestInit = {}): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    return await fetch(path.startsWith("http") ? path : `${API_BASE}${path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        Accept: "application/json",
        ...(init.headers ?? {}),
      },
    });
  } catch {
    throw new NajahError("SITE_DOWN");
  } finally {
    clearTimeout(timer);
  }
}

/**
 * The public site protects every lookup with an ALTCHA anti-bot check.
 * Automating it without permission from the Ministry of Education is not
 * allowed, so the bot refuses to run unless the operator states they have it.
 */
export function assertAutomationAuthorized() {
  if (process.env["NAJAH_AUTOMATION_AUTHORIZED"] !== "true") {
    throw new NajahError("UNAUTHORIZED_AUTOMATION");
  }
}

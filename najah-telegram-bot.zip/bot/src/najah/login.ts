import { solveAltcha } from "./altcha.js";
import { NajahError, assertAutomationAuthorized, request } from "./client.js";

export type StudentData = Record<string, unknown> & { status?: boolean; message?: string };

/**
 * Performs the same call the site's login form makes:
 * POST /api/student/student_check { student_number, student_code, altcha }
 * The response JSON is the whole result payload — the site stores it in
 * localStorage and renders results.html from it. Nothing is persisted here.
 */
export async function loginAndFetchResult(
  examNumber: string,
  secretCode: string,
): Promise<StudentData> {
  assertAutomationAuthorized();

  const altcha = await solveAltcha();

  const response = await request("/student_check", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      student_number: examNumber,
      student_code: secretCode,
      altcha,
    }),
  });

  if (response.status === 404) throw new NajahError("NOT_FOUND");
  if (response.status >= 500) throw new NajahError("SITE_DOWN");

  let payload: StudentData;
  try {
    payload = (await response.json()) as StudentData;
  } catch {
    throw new NajahError("SITE_DOWN");
  }

  if (!payload.status) throw new NajahError("BAD_CREDENTIALS", payload.message ?? "");
  return payload;
}

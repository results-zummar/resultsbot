import { createHash } from "node:crypto";
import { NajahError, request } from "./client.js";

type Challenge = {
  algorithm: string;
  challenge: string;
  salt: string;
  signature: string;
  maxnumber?: number;
};

/**
 * Computes the ALTCHA proof-of-work exactly the way the site's own widget does
 * in the browser. This is an anti-bot control: only run it when the operator
 * has explicit authorization (see assertAutomationAuthorized).
 */
export async function solveAltcha(): Promise<string> {
  const response = await request("/challenge", { method: "GET" });
  if (!response.ok) throw new NajahError("CHALLENGE_UNAVAILABLE");

  let challenge: Challenge;
  try {
    challenge = (await response.json()) as Challenge;
  } catch {
    throw new NajahError("CHALLENGE_UNAVAILABLE");
  }
  if (!challenge?.challenge || !challenge?.salt) {
    throw new NajahError("CHALLENGE_UNAVAILABLE");
  }

  const algorithm = (challenge.algorithm ?? "SHA-256").replace("-", "").toLowerCase();
  const max = challenge.maxnumber ?? 1_000_000;

  for (let number = 0; number <= max; number++) {
    const hash = createHash(algorithm).update(`${challenge.salt}${number}`).digest("hex");
    if (hash === challenge.challenge) {
      return Buffer.from(
        JSON.stringify({
          algorithm: challenge.algorithm ?? "SHA-256",
          challenge: challenge.challenge,
          number,
          salt: challenge.salt,
          signature: challenge.signature,
        }),
      ).toString("base64");
    }
  }

  throw new NajahError("CHALLENGE_UNAVAILABLE");
}

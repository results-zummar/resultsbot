import { chromium, type Browser } from "playwright";
import { BASE_URL, NajahError, TIMEOUT_MS } from "./client.js";
import type { StudentData } from "./login.js";

/**
 * najah.iq does NOT expose a PDF file. Its results page is rendered in the
 * browser from the JSON returned by /api/student/student_check, and students
 * get a paper copy through the page's own "print" button (print.css).
 *
 * So we reproduce exactly that: load the site's own results.html with the
 * result payload in localStorage and print it to PDF with the site's own
 * print stylesheet. Everything stays in memory — no file is written.
 */
let browserPromise: Promise<Browser> | null = null;

async function getBrowser(): Promise<Browser> {
  if (!browserPromise) {
    browserPromise = chromium.launch({ headless: true });
  }
  return browserPromise;
}

export async function renderResultPdf(data: StudentData): Promise<Buffer> {
  let context;
  try {
    const browser = await getBrowser();
    context = await browser.newContext({ locale: "ar-IQ" });
    const page = await context.newPage();
    page.setDefaultTimeout(TIMEOUT_MS);

    // Seed localStorage on the site's origin before the results script runs.
    await page.addInitScript((payload: string) => {
      localStorage.setItem("studentData", payload);
    }, JSON.stringify(data));

    // The site can be slow or partially broken; a rendered result is enough.
    await page
      .goto(`${BASE_URL}/results.html`, { waitUntil: "networkidle" })
      .catch(() =>
        page.goto(`${BASE_URL}/results.html`, { waitUntil: "domcontentloaded" }),
      );
    await page.waitForSelector("#resultsBody tr", { timeout: TIMEOUT_MS }).catch(() => null);

    // Hide the on-page buttons, then print with the site's print stylesheet.
    await page.addStyleTag({ content: ".button-wrapper{display:none !important}" });
    await page.emulateMedia({ media: "print" });

    const pdf = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: { top: "10mm", bottom: "10mm", left: "8mm", right: "8mm" },
    });

    return Buffer.from(pdf);
  } catch {
    throw new NajahError("PDF_FAILED");
  } finally {
    await context?.close().catch(() => undefined);
  }
}

export async function closeBrowser() {
  if (browserPromise) {
    const browser = await browserPromise;
    await browser.close().catch(() => undefined);
    browserPromise = null;
  }
}

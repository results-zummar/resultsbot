import type { StudentData } from "./login.js";

/** Basic sanity check that the payload really contains a result. */
export function hasResult(data: StudentData): boolean {
  if (!data || typeof data !== "object") return false;
  const candidates = ["data", "student", "results", "subjects", "marks"];
  return candidates.some((key) => {
    const value = (data as Record<string, unknown>)[key];
    return Array.isArray(value) ? value.length > 0 : Boolean(value);
  });
}

export function suggestedFileName(examNumber: string): string {
  return `najah-result-${examNumber.slice(-6)}.pdf`;
}
